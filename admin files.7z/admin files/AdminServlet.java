/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Dao;
import model.Member;

/**
 *
 * @author Ya Boi
 */
public class AdminServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        //get dao
        Dao dao = (Dao) request.getServletContext().getAttribute("dao");

        //get list option
        String listOption = request.getParameter("listOption").toLowerCase();

        //get table data
        String error = null;
        ArrayList<String[]> tableData = new ArrayList<>();
        
        System.out.println("VARIABLES LOADED");
        
        //if button option selected
        if( request.getParameter("buttonOption") != null ) {
            
            //get button option
            String buttonOption = request.getParameter("buttonOption");
            
            //get member/claim id
            String id = request.getParameter("id");
            
            //process option
            switch (buttonOption) {
                case "suspend":
                    if (!dao.updateStatus(id, "SUSPENDED") ) error = "Failed to suspend selected member.";
                    break;
                case "resume":
                    if (!dao.updateStatus(id, "MEMBER")) error = "Failed to restore selected member.";
                    break;
                case "approveClaim":
                    if (!dao.acceptClaim(id)) error = "Failed to approve claim.";
                    break;
                case "approveMember":
                    System.out.println("testestestes");
                    if (!dao.updateStatus(id, "MEMBER")) error = "Failed to approve member";
                    break;
            }
            
            //remove button option and member id
            request.removeAttribute("buttonOption");
            request.removeAttribute("id");            
        }

        //common header
        request.setAttribute("tableHeader", new String[]{"ID","NAME","ADDRESS","DOB","DOR","STATUS","BALANCE"} );

        //outstanding balances list
        if(listOption.contains("outstanding balances")){
            //page title, table data
            request.setAttribute("listType", "List of Outstanding Balances");
            if ( (tableData = dao.getList("outstandingBalances") ) == null) error = "Failed to get outstanding balances from the database.";
        }
        
        //claims list
        else if(listOption.contains("claims")){
            
            //page title, button type, table header, table data
            request.setAttribute("listType", "List of Claims");
            request.setAttribute("tableHeader", new String[]{"ID","MEM_ID","DATE","RATIONALE","STATUS","AMOUNT"} );
            if ( (tableData = dao.getList("claims") ) == null) error = "Failed to get list of claims from the database.";
        }
        
        //provisional members list
        else if (listOption.contains("provisional members")){
            //page title, table data
            request.setAttribute("listType", "List of Provisional Members");
            if ( (tableData = dao.getList("provisionalMembers") ) == null) error = "Failed to get provisional members from the database.";
        }
  
        //members list
        else {
            //page title, table data
            request.setAttribute("listType", "List of Members");
            if ( (tableData = dao.getList("members") ) == null) error = "Failed to get members list from database.";
        }       
        

        //if error occured go to error page
        if(error != null){
            request.setAttribute("heading", "Admin Servlet Error");
            request.setAttribute("error", error);
            request.setAttribute("log", dao.getLog());
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
        
        //add table data
        request.setAttribute("tableData", tableData);
        
        request.getRequestDispatcher("/admin.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
