/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.Date;
import java.util.concurrent.atomic.AtomicInteger;



public class User {
    private static final AtomicInteger count = new AtomicInteger(0);
    private int id = count.incrementAndGet();    
    private String fullname;
    private String password;
    private String status;
    private String address;
    private String email;
    private String dob;
    private String dor;
    private double balance;
    private int account;
    private int code;
    private int month;
    private int year;
    

    public User(int id,String fullname, String email,String status, int balance, String address,String password, int account, int code, int month, int year,String dob, String dor) {
        this.id = id;
        this.fullname = fullname;      
        this.status = status;        
        this.address = address;
        this.email = email;
        this.dob = dob;
        this.balance = balance;
        this.password = password;
        this.account = account;
        this.code  = code;
        this.month = month;
        this.year = year;
        this.dor = dor;
        
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public User() {
    }

    public User( String fullname, String email,String status, double balance, String address,String password, int account, int code, int month, int year,String dob, String dor){
        
        this.fullname = fullname;      
        this.status = status;        
        this.address = address;
        this.email = email;
        this.dob = dob;
        this.balance = balance;
        this.password = password;
        this.account = account;
        this.code  = code;
        this.month = month;
        this.year = year;
        this.dor = dor;
        
        
    }
    
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public double getBalance() {
        return balance;
    }

    public void setBalance(double balance) {
        this.balance = balance;
    }
    
    

    public int getAccount() {
        return account;
    }

    public void setAccount(int account) {
        this.account = account;
    }

    

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }
  

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public int getMonth() {
        return month;
    }

    public void setMonth(int month) {
        this.month = month;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public String getDor() {
        return dor;
    }

    public void setDor(String dor) {
        this.dor = dor;
    }

    
    
    

 
    
    
}
