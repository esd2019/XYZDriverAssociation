/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.User;

/**
 *
 * @author tuan
 */
public class UserDAOImpl implements UserDAO {

    Connection cons= DBConnect.getConnection();

    
    
    

    @Override
    public boolean checkAccountExist(String email) {
        PreparedStatement ps = null;
        String sql = "select email from MEMBER where email='" + email + "'";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING EMAIL");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    @Override
    public void insertAccount(User user) {
        PreparedStatement ps = null;
        String sql = "insert into MEMBER (fullname, email, dob,status,balance,address,password, account, code,month,year_1) VALUES (?,?,?,?,?,?,?,?,?,?,?)";
        try {
            ps = cons.prepareCall(sql);
            ps.setString(1, user.getFullname());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getDob());
            ps.setBoolean(4, user.isStatus());
            ps.setInt(5, user.getBalance());
            ps.setString(6, user.getAddress());
            ps.setString(7, user.getPassword());
            ps.setInt(8, user.getAccount());
            ps.setInt(9, user.getCode());
            ps.setString(10, user.getMonth());
            ps.setString(11, user.getYear());
            ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        
        
        
        
        
    }

    @Override
    public boolean checkLogin(String email, String password) {
        PreparedStatement ps = null;
        String sql = "select * from MEMBER where email='" + email + "' AND password='" + password + "'";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING LOGIN");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    @Override
    public String getUserNameFromEmail(String email) {
        PreparedStatement ps = null;
        String sql = "select fullname from MEMBER where email='" + email + "'";
        String username = "";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                username = rs.getString("fullname");
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING LOGIN");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return username;
    }

    @Override
    public boolean checkAccountExistBaseOnEmailAndPassword(String email, String password) {
        PreparedStatement ps = null;
        String sql = "select email from MEMBER where email='" + email + "' and password='" + password + "'";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING EXIST");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    @Override
    public String getUserNameFromUserID(String id) {
        PreparedStatement ps = null;
        String sql = "select username from users where userid='" + id + "'";
        String username = "";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                username = rs.getString("username");
            }

        } catch (Exception e) {
            System.err.println("ERROR GET USERNAME");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return username;
    }

    @Override
    public int getUserIDFromEmail(String email) {
        PreparedStatement ps = null;
        int userid = 0;
        if (!email.equals("")) {

            String sql = "select userid from users where email='" + email + "'";

            try {
                ps = cons.prepareCall(sql);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    userid = rs.getInt("userid");
                }

            } catch (Exception e) {
                System.err.println("ERROR GET USERID");
            } finally {
                try {
                    cons.close();
                } catch (SQLException ex) {
                    Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
                }
            }

        }

        return userid;
    }

    @Override
    public User getUserDetailByEmail(String email) {
        PreparedStatement ps = null;
        User user = new User();
        try {

            String sql = "SELECT * FROM MEMBER WHERE email='" + email + "'";
            ps = cons.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                user.setFullname(rs.getString("fullname"));
                user.setEmail(rs.getString("email"));
                user.setDob(rs.getString("dob"));
                user.setAddress(rs.getString("address"));
                user.setPassword(rs.getString("password"));
                user.setAccount(rs.getInt("account"));
                user.setCode(rs.getInt("code"));
                user.setMonth(rs.getString("month"));
                user.setYear(rs.getString("year_1"));
                
                    

            }

        } catch (SQLException ex) {

            System.err.println("NO USER DETAIL FOUND");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return user;
    }

    @Override
    public void updateAccount(User user) {
        PreparedStatement ps = null;
        String sql = "UPDATE `MEMBER` SET `MEMBER`.fullname=?, `MEMBER`.email=?, `MEMBER`.dob=?, `MEMBER`.status=?, `MEMBER`.balance=?, `MEMBER`.address=?, `MEMBER`.password=?, `MEMBER`.account=?, `MEMBER`.code=?, `MEMBER`.month=?,`MEMBER`.year_1=? WHERE `MEMBER`.email=?";
        try {
            ps = cons.prepareCall(sql);
            ps.setString(1, user.getFullname());
            ps.setString(2, user.getEmail());
            ps.setString(3, user.getDob());
            ps.setBoolean(4, user.isStatus());
            ps.setInt(5, user.getBalance());
            ps.setString(6, user.getAddress());
            ps.setString(7, user.getPassword());
            ps.setInt(8, user.getAccount());
            ps.setInt(9, user.getCode());
            ps.setString(10, user.getMonth());
            ps.setString(11, user.getYear());
            ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String getUserEmailByUserID(String id) {
        PreparedStatement ps = null;
        String sql = "select email from user where userid='" + id + "'";
        String email = "";
        try {
            ps = cons.prepareCall(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                email = rs.getString("email");
            }

        } catch (Exception e) {
            System.err.println("ERROR GET EMAIL");
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }

        return email;
    }

    @Override
    public void inserAcc(User user) {
        PreparedStatement ps = null;
        String sql = "insert into PEOPLE (password, account, code,month,year_1,status) VALUES (?,?,?,?,?,?)";
        try {
            ps = cons.prepareCall(sql);
            ps.setString(1, user.getPassword());
            ps.setInt(2, user.getAccount());
            ps.setInt(3, user.getCode());
            ps.setString(4, user.getMonth());
            ps.setString(5, user.getYear());
            ps.setBoolean(6, user.isStatus());
            ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                ps.close();
            } catch (SQLException ex) {
                Logger.getLogger(UserDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        } //To change body of generated methods, choose Tools | Templates.
    }
    
        

}
