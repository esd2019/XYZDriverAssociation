/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testing;

import java.sql.Date;
import java.util.ArrayList;
import java.util.Calendar;
import model.Dao;
import model.Member;
import model.User;

/**
 *
 * @author Ya Boi
 */
public class DaoTester {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        //create database connection
        String driver = "org.apache.derby.jdbc.ClientDriver";
        Dao dao = new Dao(driver, "jdbc:derby://localhost:1527/XYZ_Drivers", "username", "password");
        dao .loadDriver();
        dao.connect();
        
        Calendar calendar = Calendar.getInstance();
        java.util.Date currentDate = calendar.getTime();
        java.sql.Date dob = new java.sql.Date(currentDate.getTime());
        
        Member m = dao.getMember("me-aydin");
        
        if (m == null) { System.out.println("Log:"); for (String l : dao.getLog()) System.out.println(l); }
        else {
            System.out.println("Member:");
            System.out.println("- id: " + m.getId());
            System.out.println("- Name: " + m.getName());
            System.out.println("- address: " + m.getAddress());
            System.out.println("- dob: " + m.getDob());
            System.out.println("- dor: " + m.getDor());
            System.out.println("- status: " + m.getStatus());
            System.out.println("- balance: " + m.getBalance());
        }
    }
    
}
