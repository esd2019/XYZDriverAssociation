/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Dao;
import model.User;

/**
 *
 * @author Ya Boi
 */
public class LoginServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        response.setContentType("text/html;charset=UTF-8");
        
        //get servlet context
        ServletContext servletContext = request.getServletContext();
        
        //get dao
        Dao dao = (Dao) servletContext.getAttribute("dao");
        
        //check if database connection is succesful
        if(dao.getDriver() == null || dao.getConnection() == null){
            request.setAttribute("heading", "Failed to connect to database.");
            request.setAttribute("error", dao.getLastLogEntry());
            request.getRequestDispatcher("error.jsp").forward(request, response);
        }        
        
        //get login info from form data
        String username = (String)request.getParameter("username");
        String password = (String)request.getParameter("password");           
        
        //attempt to get user with login info
        User user = dao.getUser(username, password);
        
        //if login fails return to login page
        if(user == null){
            request.setAttribute("error", dao.getLastLogEntry());
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
        
        //destroy previous session if exists
        if(request.getSession(false) != null) request.getSession().invalidate();
        
        //create new session for user
        HttpSession session = request.getSession();
        
        //add user object to session
        session.setAttribute("user", user);
        
        //USER - navigate to user dashboard if user logged in
        if(user.getStatus().equals("APPLIED") || user.getStatus().equals("APPROVED")) request.getRequestDispatcher("userDashboard.jsp").forward(request, response);    
        
        //ADMIN - navigate to admin dashboard if admin logged in
        else if(user.getStatus().equals("ADMIN")) request.getRequestDispatcher("adminDashboard.jsp").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
