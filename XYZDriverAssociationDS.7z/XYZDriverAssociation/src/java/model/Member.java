/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.sql.Date;
import javafx.animation.Animation.Status;

/**
 *
 * @author Ya Boi
 */
public class Member {
    
    private String id;
    private String name;
    private String address;
    private Date dob;
    private Date dor;
    private String status;
    private double balance;
    
    Member (String id, String name, String address, Date dob, Date dor, String status, double balance){
        this.id = id;
        this.name = name;
        this.address = address;
        this.dob = dob;
        this.dor = dor;
        this.status = status;
        this.balance = balance;
    }

    public String getId() { return id; }

    public String getName() { return name; }

    public String getAddress() { return address; }
    
    public Date getDob() { return dob; }

    public Date getDor() { return dor; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; } 
    
    public double getBalance() { return balance; }
    public void setBalance(double balance) { this.balance = balance; }
}
