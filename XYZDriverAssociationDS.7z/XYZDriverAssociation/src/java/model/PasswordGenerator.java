/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.ArrayList;
import java.util.Random;

/**
 *
 * @author Ya Boi
 */
public class PasswordGenerator {
    
    private Random r = new Random();
    private String chars = "ABCDEFGHIJKLMNOPQRSTYUVXYZabcdefghijklmnopqrstuvwxyz1234567890!£$%^&*()_+-=/";
    private int numberOfChars = chars.length();
    
    String password;
    
    ArrayList<String> log = new ArrayList<>();
    
    public boolean generatePassword(int length){
        
        if (length < 1){
            log.add("Invalid password length. Must be greater than 1.");
            return false;
        }
        
        StringBuilder s = new StringBuilder(length);
        
        for (int i = 1; i <= length; i++) s.append(chars.charAt(r.nextInt(numberOfChars)));
        
        password = s.toString();
        
        return true;
    }
    
    public String getPassword(){ 
        String p = password; 
        password = null; 
        return p; 
    }
}
