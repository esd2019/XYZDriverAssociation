/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.DBConnect;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Period;
import java.util.ArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Admin;

/**
 *
 * @author tuan
 */
public class AdminDAOImpl implements AdminDAO {

    Connection cons = DBConnect.getConnection();
    Statement statement = null;
    ResultSet resultSet = null;
    ResultSetMetaData resultSetMetaData = null;

    @Override
    public boolean checkLogin(Admin admin) {

        String sql = "select * from ADMIN where adminuser='" + admin.getName() + "' AND adpassword='" + admin.getPassword() + "'";
        try {
            PreparedStatement ps = cons.prepareCall(sql);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING ADMIN Login");
        } finally {
            try {
                cons.close();
            } catch (SQLException ex) {
                //Logger.getLogger(BrandDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    @Override
    public void insertAdmin(Admin admin) {

        String sql = "INSERT into `admin` (admin.id, `admin`.name, `admin`.password) values(?,?)";
        try {
            PreparedStatement ps = cons.prepareCall(sql);
            ps.setString(1, admin.getName());
            ps.setString(2, admin.getName());
            ps.setString(3, admin.getPassword());

            ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                cons.close();
            } catch (SQLException ex) {
                //Logger.getLogger(BrandDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String getTable (String listType){
        
        //set query 
        String query = "";
        switch(listType) {
            case "members":
                query = "SELECT * FROM USERS";
                break;
            case "provisionalMembers":
                query = "SELECT * FROM USERS WHERE STATUS='Applied'";
                break;
            case "outstandingBalances":
                query = "SELECT * FROM OUTSTANDING";
                break;
            case "claims":
                query = "SELECT * FROM CLAIMS";
                break;
            case "thisYearPayments":
                query = "SELECT * FROM PAYMENTS";
                break;
            case "thisYearClaims":
                query = "SELECT * FROM CLAIMS";
                break;
        }
        
        //execute query
        try {
        statement = cons.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        resultSet = statement.executeQuery(query);
        resultSetMetaData = resultSet.getMetaData();
        }
        catch(SQLException e){
            System.out.println(e);
            return null;
        }
        
        ArrayList<String[]> listTable = new ArrayList<>();
        
        
        //get payments / claims this year
        if(listType.equals("thisYearClaims") || listType.equals("thisYearPayments")){
            LocalDate startOfYear = LocalDate.of(LocalDate.now().getYear(), 1, 1);
            try {
                while(resultSet.next()){
                    LocalDate claimDate = resultSet.getDate("DATE").toLocalDate();
                    if (claimDate.isAfter(startOfYear)) {
                        
                        //add claim
                        if(listType.equals("thisYearClaims")){
                            String id = resultSet.getString("ID");
                            String email = resultSet.getString("EMAIL");
                            String rational = resultSet.getString("RATIONAL");
                            String date = resultSet.getString("DATE");
                            String amount = resultSet.getString("AMOUNT");
                            String status = resultSet.getString("STATUS");
                            
                            listTable.add(new String[] {id, email, rational, date, amount, status});
                        }
                        
                        //add payment
                        else if(listType.equals("thisYearPayments")) {
                            String id = resultSet.getString("ID");
                            String mem_id = resultSet.getString("MEM_ID");
                            String outstanding_id = resultSet.getString("OUTSTANDING_ID");
                            String type = resultSet.getString("TYPE");
                            String amount = resultSet.getString("AMOUNT");
                            String code = resultSet.getString("CODE");
                            String description = resultSet.getString("DESCRIPTION");
                            String date = resultSet.getString("DATE");
                            
                            listTable.add(new String[] {id, mem_id, outstanding_id, type, amount, code, description, date});
                        }
                        
                        if ((listTable = resultSetToArrayList()) == null) return null;
                    }
                }
            } catch (SQLException ex) {
                Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            } 
        }
        
        //get result set as array list
        else if ( (listTable = resultSetToArrayList()) == null) return null;
        
        //get array list as a html table
        return makeHtmlTable(listTable);
    }
    
    @Override
    public ArrayList<String[]> resultSetToArrayList() {
        
        ArrayList<String[]> output = new ArrayList<>();
        
        //check if null
        if (resultSet == null || resultSetMetaData == null) return null;

        try{
            int cols = resultSetMetaData.getColumnCount();
            String[] row = new String[cols];
            
            //get header
            for (int col = 0; col < cols; col++) row[col] = resultSetMetaData.getColumnName(col+1);
            output.add(row.clone());
            
            //get data
            while (resultSet.next()) { 
              for (int col = 0; col < cols; col++) row[col] = resultSet.getString(col+1);
              output.add(row.clone());
            }                
        }
        catch(SQLException e){
            System.out.println(e);
            return null;
        }
        
        return output;
    } //rsToList
    
    @Override
    public String makeHtmlTable(ArrayList list) {
        
        StringBuilder b = new StringBuilder();
        
        b.append("<table id=\"table_id\">");
        //haeder
        b.append("<thead>");
        b.append("<tr>");
        for (String col : (String[]) list.get(0)) b.append("<th>").append(col).append("</th>"); 
        b.append("</tr>");
        b.append("</thead>");
        //body
        b.append("<tbody>");
        for (int i = 1; i < list.size(); i++){
            b.append("<tr>");
            for (String col : (String[]) list.get(i)) b.append("<td>").append(col).append("</td>");
            b.append("</tr>");
        }
        b.append("</body>");
        b.append("</table>");

        return b.toString();
    }
    
    @Override
    public void acceptClaim(String email){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE CLAIMS SET STATUS='Approved' WHERE EMAIL=" + email);
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void approveMember(String email){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE USERS SET STATUS='Approved' WHERE EMAIL='" + email + "'");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void suspendMember(String email){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE USERS SET STATUS='Suspended' WHERE EMAIL='" + email + "'");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public boolean checkUsername(String username){
        try {
            statement = cons.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            resultSet = statement.executeQuery("SELECT * FROM ADMIN WHERE ADMINUSER='" + username + "'");
            
            while (resultSet.next()) return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
    
    @Override
    public boolean checkMemberAge (String email){
        
        try {
            
            //get member date of registration
            statement = cons.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM USERS WHERE EMAIL='" + email + "'");
            Date d = null;
            while (resultSet.next()) d = resultSet.getDate("DOR");
            LocalDate dor = d.toLocalDate();
            
            //get current date
            LocalDate now = LocalDate.now();
            
            //get difference
            Period period = Period.between(dor, now);
            int months = period.getMonths();
            
            //return true if valid
            if (months  >= 6) return true;
            
        } 
        catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return false;
    }
    
    @Override
    public boolean checkNumberOfClaims (String email){
        
        try {
            
            //get all claims
            statement = cons.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM CLAIMS WHERE EMAIL='" + email + "'");
            
            //get all claims in last year
            LocalDate startOfYear = LocalDate.of(LocalDate.now().getYear(), 1, 1);
            int numberOfClaims = 0;
            while (resultSet.next()){
                LocalDate claimDate = resultSet.getDate("DATE").toLocalDate();
                if (claimDate.isAfter(startOfYear)) numberOfClaims++;
            }
            
            //if less than 2 claims return true
            if (numberOfClaims < 2) return true;
        } 
        catch (SQLException ex) {
            System.out.println(ex);
        }
        
        return false;
        
    }
    
    @Override
    public void chargeMembers (float payoutShare){
        
        System.out.println("ENTER");
        
        try {
            
            //for each approved member
            statement = cons.createStatement();
            resultSet = statement.executeQuery("SELECT * FROM USERS WHERE STATUS='Approved'");
            
            System.out.println("TESTTEST");
            
            int count = 300;
            
            //add outstanding charge
            while(resultSet.next()){
                
                System.out.println("Record");
                
                int id = count;
                
                int user_id = resultSet.getInt("ID");
                String email = resultSet.getString("EMAIL");
                String fee_code = "000";
                String description = "Annual payout share";
                float amount = payoutShare;
                String status = "Due";
                
                PreparedStatement ps = cons.prepareCall("insert into OUTSTANDING (id, user_id, email, fee_code, desciption, amount, status) VALUES (?,?,?,?,?,?,?)");
                ps.setInt(1, id);
                ps.setInt(2, user_id);
                ps.setString(3, email);
                ps.setString(4, fee_code);
                ps.setString(5, description);
                ps.setFloat(6, amount);
                ps.setString(7, status);
                
                ps.executeUpdate();
                count++;
            }
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        //add outstanding charge
    }
}
