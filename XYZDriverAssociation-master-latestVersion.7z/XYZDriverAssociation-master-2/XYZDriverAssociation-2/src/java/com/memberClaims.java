/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Claim;

/**
 *
 * @author jennistly
 */
public class memberClaims extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        HttpSession s = request.getSession();
        
        String rational = request.getParameter("rational").trim();
        String date = request.getParameter("date").trim();
        String amount = request.getParameter("amount").trim();
        String email = request.getParameter("email").trim();
        String amount_err = "err", rational_err = "err", date_err = "err", email_err = "err";
        String status = "Applied";

            if (email.equals("")) {

                request.setAttribute("email_err", "Please input your email!");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_err", "Invalid email format!");

            } else {
                request.setAttribute("email", email);
                email_err = "";
            }

            if (rational.equals("")) {

                request.setAttribute("rational_err", "Please give us more deatails about your claims");

            } else {
                request.setAttribute("rational", rational);
                rational_err = "";
            }

            if (date.equals("")) {

                request.setAttribute("date_err", "Please give us exactly time");

            } else {
                request.setAttribute("date", date);
                date_err = "";
            }

            if (amount.equals("")) {

                request.setAttribute("amount_err", "Please give bill");

            } else {
                request.setAttribute("amount", amount);
                amount_err = "";
            }

            String url = "";

            if (!rational_err.equals("") || !date_err.equals("") || !email_err.equals("") || !amount_err.equals("")) {
                url = "user/claims.jsp";
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            } else {
                url = "user/userdashboard.jsp";
                Claim u = new Claim(email, rational, date, Double.parseDouble(amount), status);
                new UserDAOImpl().insertClaim(u);

                s.setAttribute("email", email);
                s.setAttribute("success", "Update SUCCESSFULLY!");
                response.sendRedirect("user/userdashboard.jsp");
            }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
