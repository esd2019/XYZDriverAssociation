/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import javax.servlet.ServletContext;
import javax.servlet.ServletContextEvent;
import model.Dao;

/**
 * Web application lifecycle listener.
 *
 * @author Ya Boi
 */
public class ServletContextListener implements javax.servlet.ServletContextListener {

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        
        //get servlet context
        ServletContext servletContext = sce.getServletContext();
        
        //get database login details
        String driver = servletContext.getInitParameter("driver");
        String url = servletContext.getInitParameter("url");
        String username = servletContext.getInitParameter("username");
        String password = servletContext.getInitParameter("password");
        
        //create dao and attempt connection 
        Dao dao = new Dao(driver, url, username, password);
        dao.loadDriver();
        dao.connect();
        
        //add database connection to servlet context
        servletContext.setAttribute("dao", dao);
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        
        //get servlet context
        ServletContext servletContext = sce.getServletContext();
        
        //close connection 
        Dao dao = (Dao) servletContext.getAttribute("dao");
        dao.closeAll();
    }
}
