/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author jennistly
 */
public class memberValidate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        
            // <editor-fold defaultstate="collapsed" desc="Login Action">
            //final String secretKey = "secretkeysecretkey";
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            boolean rememberMe = request.getParameter("remember") != null;
            //String encryptedPassword = AES.encrypt(password, secretKey);
            //String username = new UserDAOImpl().getUserNameFromEmail(email);

            String password_err = "err", email_err = "err";

            if (email.equals("") || password.equals("")) {

                request.setAttribute("login_err", "Please input email and password to login!");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_login_err", "Invalid email format!");

            } else {
                if (!new UserDAOImpl().checkLogin(email, password)) {
                    request.setAttribute("login_err", "Login failed!");
                } else {

                    email_err = "";
                    password_err = "";
                }
            }

            String url = "";

            if (!password_err.equals("") || !email_err.equals("")) {
                url = "/login.jsp";

            } else {
                url = request.getParameter("checkout") != null ? "/checkout.jsp" : "/userdashboard.jsp";
                HttpSession s = request.getSession();
                //s.setAttribute("username", username);
                s.setMaxInactiveInterval(1200);// 20 minutes
                s.setAttribute("email", email);

                if (rememberMe) {
                    Cookie c = new Cookie("email", email);
                    c.setMaxAge(1200);// expire in 20 minutes
                    response.addCookie(c);

                    Cookie c1 = new Cookie("password", password);
                    c.setMaxAge(1200);
                    response.addCookie(c1);
                }
            }

            if (url.equals("/checkout.jsp")) {
                response.sendRedirect("AccountController?action=checkout");
            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            }
    }
        
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
