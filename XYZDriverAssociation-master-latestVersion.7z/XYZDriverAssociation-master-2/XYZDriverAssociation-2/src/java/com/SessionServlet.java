/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;

/**
 *
 * @author ninhthelam
 */
public class SessionServlet extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        HttpSession session = request.getSession();
     
        session.setMaxInactiveInterval(300);    // session timeout in seconds
     
        request.getSession().removeAttribute("success");
        String action = request.getParameter("action");
        if (action == null) {
            User user = checkCookie(request);
            if (user == null) {

                //khong check remember me, nghia la khong luu cookie trong browser
                // session.removeAttribute("username");
                session.removeAttribute("email");

                request.getRequestDispatcher("/user/userdashboard.jsp").forward(request, response);

            } else {//check remeber me, nghia la co luu cookie trong browser
                if (new UserDAOImpl().checkLogin(user.getEmail(), user.getPassword())) {
                    //session.setAttribute("username", new UserDAOImpl().getUserNameFromEmail(user.getEmail()));
                    session.setAttribute("email", user.getEmail());
                    request.getRequestDispatcher("/user/userdashboard.jsp").forward(request, response);
                }
            }
        } else if (action.equals("logout")) {
            request.getRequestDispatcher("homepage.jsp").forward(request, response);
            // <editor-fold defaultstate="collapsed" desc="Log Out Action">
            //remove session
            //session.removeAttribute("username");
            session.removeAttribute("email");
            //remove cookie
            Cookie[] cookies = request.getCookies();
            for (Cookie c : cookies) {
                if (c.getName().equalsIgnoreCase("email")) {
                    c.setMaxAge(0);
                    response.addCookie(c);
                }
                if (c.getName().equalsIgnoreCase("password")) {
                    c.setMaxAge(0);
                    response.addCookie(c);
                }
            }
            request.getRequestDispatcher("homepage.jsp").forward(request, response);
            //</editor-fold>
        }
        
    }
    private User checkCookie(HttpServletRequest request) {
        // <editor-fold defaultstate="collapsed" desc="check cookie">
        Cookie[] cookies = request.getCookies();
        User user = null;
        String email = "", password = "";

        if (cookies != null) {

            for (Cookie c : cookies) {
                if (c.getName().equalsIgnoreCase("email")) {
                    email = c.getValue();
                }
                if (c.getName().equalsIgnoreCase("password")) {
                    password = c.getValue();
                }

            }
            if (!email.isEmpty() && !password.isEmpty()) {
                user = new User("", email, "", 0, "", password, 0, 0, 0, 0, "","");
            }

        }
        return user;
        // </editor-fold>
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
