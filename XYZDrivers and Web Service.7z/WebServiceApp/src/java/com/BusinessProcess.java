/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.Calendar;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.ejb.Stateless;

/**
 *
 * @author Ya Boi
 */
@WebService(serviceName = "WebService")
@Stateless()
public class BusinessProcess {

    /**
     * Web service operation - checks if account is at least six months old
     * 
     * @param email of member to validate
     * 
     * @return boolean indicating valid claim
     */
    @WebMethod(operationName = "reportAnnualPayouts")
    public float getYearlyPayouts() {
        
        float payoutTotal = 0;
        
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/esd_coursework", "root", "root");
            Statement statement = con.createStatement();
            
            //get start of year date
            LocalDate yearBeginningDate = LocalDate.now().minusDays(365);
            
            //get approved claims
            ResultSet resultSet = statement.executeQuery("SELECT * FROM CLAIMS WHERE STATUS='Approved'");
            while (resultSet.next()) {
                
                //if claim dated this year add payout amount to total
                LocalDate claimDate = resultSet.getDate("DATE").toLocalDate();
                if (claimDate.isAfter(yearBeginningDate)) payoutTotal += resultSet.getFloat("AMOUNT");
            }

        } 
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(BusinessProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return payoutTotal;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "reportAnnualIncome")
    public float getYearlyIncome() {
        
        float incomeTotal = 0;
        
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/esd_coursework", "root", "root");
            Statement statement = con.createStatement();
            
            //get start of year date
            LocalDate startOfYear = LocalDate.of(LocalDate.now().getYear(), 1, 1);
            
            //get approved claims
            ResultSet resultSet = statement.executeQuery("SELECT * FROM PAYMENTS");
            while (resultSet.next()) {
                
                //if claim dated this year add payout amount to total
                LocalDate claimDate = resultSet.getDate("DATE").toLocalDate();
                if (claimDate.isAfter(startOfYear)) incomeTotal += resultSet.getFloat("AMOUNT");
            }

        } 
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(BusinessProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return incomeTotal;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "checkMemberAge")
    public Boolean checkMemberAge(@WebParam(name = "email") String email) {
        
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/esd_coursework", "root", "root");
            Statement statement = con.createStatement();
            
            //get member date of registration
            ResultSet resultSet = statement.executeQuery("SELECT * FROM USERS WHERE EMAIL='" + email + "'");
            Date d = null;
            while (resultSet.next()) d = resultSet.getDate("DOR");
            LocalDate dor = d.toLocalDate();
            
            //get current date
            LocalDate now = LocalDate.now();
            
            //get difference
            Period period = Period.between(dor, now);
            int months = period.getMonths();
            
            //return true if valid
            if (months  >= 6) return true;
            
        } 
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(BusinessProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "checkNumberOfClaims")
    public Boolean checkNumberOfClaims(@WebParam(name = "email") String email) {
        
        try {
            //connect to database
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            Connection con = DriverManager.getConnection("jdbc:derby://localhost:1527/esd_coursework", "root", "root");
            Statement statement = con.createStatement();
            
            //get start of year date
            LocalDate startOfYear = LocalDate.of(LocalDate.now().getYear(), 1, 1);
            
            //get all claims in last year
            ResultSet resultSet = statement.executeQuery("SELECT * FROM CLAIMS WHERE EMAIL='" + email + "'");
            int numberOfClaims = 0;
            while (resultSet.next()){
                LocalDate claimDate = resultSet.getDate("DATE").toLocalDate();
                if (claimDate.isAfter(startOfYear)) numberOfClaims++;
            }
            
            //if less than 2 claims return true
            if (numberOfClaims < 2) return true;
            
        } 
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(BusinessProcess.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
}
