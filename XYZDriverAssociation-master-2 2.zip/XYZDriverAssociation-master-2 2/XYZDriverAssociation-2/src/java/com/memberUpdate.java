/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.User;

/**
 *
 * @author jennistly
 */
public class memberUpdate extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        HttpSession s = request.getSession();
        
        
        
         
        response.setContentType("text/html;charset=UTF-8");
        String email = request.getParameter("email").trim();
        String fullname = request.getParameter("fullname").trim();
        String status = "Applied";
        String dob = request.getParameter("dob").trim();
        String dor = request.getParameter("dor").trim();
        String address = request.getParameter("address").trim();
        int balance = 0;
        String password = request.getParameter("password").trim();
        String account = request.getParameter("account").trim();
        String code = request.getParameter("code").trim();
        String month = request.getParameter("month").trim();
        String year = request.getParameter("year").trim();
        
       
      
        
        

        String password_err = "err", account_err = "err", code_err = "err", month_err = "err", year_err = "err";
        String email_err = "err", fullname_err = "err", address_err = "err";

        if (fullname.equals("")) {

            request.setAttribute("fullname_err", "Please input your user name");

        } else if (!fullname.matches("^[a-zA-Z0-9]+(([a-zA-Z 0-9])?[a-zA-Z0-9]*)*$") || fullname.length() < 6 || fullname.length() > 20) {
            request.setAttribute("fullname_err", "the length is 6 to 20, no space, no special character");
        } else {
            request.setAttribute("fullname", fullname);
            fullname_err = "";
        }

        if (email.equals("")) {

            request.setAttribute("email_err", "Please input your email!");

        } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
            request.setAttribute("email_err", "Invalid email format!");

        } else {
            request.setAttribute("email", email);
            email_err = "";
        }

        if (address.equals("")) {

            request.setAttribute("address_err", "Please input your address!");

        } else if (!address.matches("^([a-zA-Z0-9]+\\s)*[a-zA-Z0-9]+$") || address.length() < 6 || address.length() > 300) {
            request.setAttribute("address_err", "10 to 300 characters required, no more than 1 space, no special characters");

        } else {
            request.setAttribute("address", address);
            address_err = "";
        }
        if (password.equals("")) {

            request.setAttribute("password_err", "Please generate your password!");

        } else {
            request.setAttribute("password", password);
            password_err = "";
        }
        if (account.equals("")) {

            request.setAttribute("account_err", "Please input your account number!");

        } else if (account.length() == 16) {
            request.setAttribute("account_err", "invalid numbers account");

        } else {
            request.setAttribute("account", account);
            account_err = "";
        }
        if (code.equals("")) {

            request.setAttribute("code_err", "Please input your security code!");

        } else {
            request.setAttribute("code", code);
            code_err = "";
        }

        if (month.equals("")) {

            request.setAttribute("month_err", "Please select month!");

        } else {
            request.setAttribute("month", month);
            month_err = "";
        }
        if (year.equals("")) {

            request.setAttribute("year_err", "Please select year!");

        } else {
            request.setAttribute("year", year);
            year_err = "";
        }

        String url = "";

        if (!email_err.equals("") || !fullname_err.equals("") || !address_err.equals("") || !password_err.equals("") || !account_err.equals("") || !code_err.equals("") || !month_err.equals("") || !year_err.equals("")) {
            url = "user/userprofile.jsp";
            RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
            rd.forward(request, response);
        } else {
            url = "user/userdashboard.jsp";
            //String encryptedPassword = AES.encrypt(password, secretKey);
            User u = new User(fullname, email, status, balance, address, password, Integer.parseInt(account), Integer.parseInt(code), Integer.parseInt(month), Integer.parseInt(year), dob, dor);
            new UserDAOImpl().updateAccount(u);

            s.setAttribute("email", email);
            s.setAttribute("success", "Update SUCCESSFULLY!");
            response.sendRedirect("user/userdashboard.jsp");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
