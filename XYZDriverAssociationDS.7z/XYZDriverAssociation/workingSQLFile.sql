/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  Ya Boi
 * Created: 17-Nov-2019
 */

CREATE TABLE "CLAIMS" (
    "ID" INTEGER not null primary key GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),
    "MEM_ID" VARCHAR(30) not null,
    "DATE" DATE not null,
    "RATIONALE" VARCHAR(30) not null,
    "STATUS" VARCHAR(10) not null,
    "AMOUNT" FLOAT not null
);

CREATE TABLE "MEMBERS" (
    "ID" VARCHAR(30) primary key not null,
    "NAME" VARCHAR(30),
    "ADDRESS" VARCHAR(60),
    "DOB" DATE default null,
    "DOR" DATE default null,
    "STATUS" VARCHAR(10) not null,
    "BALANCE" float not null
);

INSERT INTO MEMBERS VALUES('me-aydin','Mehmet Aydin','148 Station Road, London, N3 25G','1968-10-20','2015-01-26','APPLIED',0);

CREATE TABLE "PAYMENTS" (
    "ID" INTEGER not null primary key GENERATED ALWAYS AS IDENTITY(START WITH 1, INCREMENT BY 1),
    "MEM_ID" VARCHAR(30) not null,
    "TYPE_OF_PAYMENT" VARCHAR(10) not null,
    "AMOUNT" FLOAT not null,
    "DATE" DATE not null
);

CREATE TABLE "USERS" (
    "ID" VARCHAR(30) not null primary key,
    "PASSWORD" VARCHAR(30) not null,
    "STATUS" VARCHAR(10) not null
);

INSERT INTO USERS VALUES('user','user','MEMBER');
INSERT INTO USERS VALUES('admin','admin','ADMIN');
INSERT INTO USERS VALUES('me-aydin','201068','APPLIED');
