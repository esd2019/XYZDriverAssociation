/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import model.DBConnect;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Admin;

/**
 *
 * @author tuan
 */
public class AdminDAOImpl implements AdminDAO {

    Connection cons = DBConnect.getConnection();
    Statement statement = null;
    ResultSet resultSet = null;
    ResultSetMetaData resultSetMetaData = null;

    @Override
    public boolean checkLogin(Admin admin) {

        String sql = "select * from ADMIN where adminuser='" + admin.getName() + "' AND adpassword='" + admin.getPassword() + "'";
        try {
            PreparedStatement ps = cons.prepareCall(sql);
            resultSet = ps.executeQuery();
            while (resultSet.next()) {
                return true;
            }

        } catch (Exception e) {
            System.err.println("ERROR CHECKING ADMIN Login");
        } finally {
            try {
                cons.close();
            } catch (SQLException ex) {
                //Logger.getLogger(BrandDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return false;
    }

    @Override
    public void insertAdmin(Admin admin) {

        String sql = "INSERT into `admin` (admin.id, `admin`.name, `admin`.password) values(?,?)";
        try {
            PreparedStatement ps = cons.prepareCall(sql);
            ps.setString(1, admin.getName());
            ps.setString(2, admin.getName());
            ps.setString(3, admin.getPassword());

            ps.executeUpdate();

        } catch (Exception e) {
            System.err.println(e.getMessage());
        } finally {
            try {
                cons.close();
            } catch (SQLException ex) {
                //Logger.getLogger(BrandDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public String getTable (String listType){
        
        //set query 
        String query = "";
        switch(listType) {
            case "members":
                query = "SELECT * FROM USERS";
                break;
            case "provisionalMembers":
                query = "SELECT * FROM USERS WHERE STATUS='Applied'";
                break;
            case "outstandingBalances":
                query = "SELECT * FROM OUTSTANDING";
                break;
            case "claims":
                query = "SELECT * FROM CLAIMS";
                break;
        }
            
        //execute query
        try {
        statement = cons.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
        resultSet = statement.executeQuery(query);
        resultSetMetaData = resultSet.getMetaData();
        }
        catch(SQLException e){
            System.out.println(e);
            return null;
        }
        
        //get result set as array list
        ArrayList<String[]> listTable;
        if ( (listTable = resultSetToArrayList()) == null) return null;
        
        //get array list as a html table
        return makeHtmlTable(listTable);
    }
    
    @Override
    public ArrayList<String[]> resultSetToArrayList() {
        
        ArrayList<String[]> output = new ArrayList<>();
        
        //check if null
        if (resultSet == null || resultSetMetaData == null) return null;

        try{
            int cols = resultSetMetaData.getColumnCount();
            String[] row = new String[cols];
            
            //get header
            for (int col = 0; col < cols; col++) row[col] = resultSetMetaData.getColumnName(col+1);
            output.add(row.clone());
            
            //get data
            while (resultSet.next()) { 
              for (int col = 0; col < cols; col++) row[col] = resultSet.getString(col+1);
              output.add(row.clone());
            }                
        }
        catch(SQLException e){
            System.out.println(e);
            return null;
        }
        
        return output;
    } //rsToList
    
    @Override
    public String makeHtmlTable(ArrayList list) {
        
        StringBuilder b = new StringBuilder();
        
        b.append("<table id=\"table_id\">");
        //haeder
        b.append("<thead>");
        b.append("<tr>");
        for (String col : (String[]) list.get(0)) b.append("<th>").append(col).append("</th>"); 
        b.append("</tr>");
        b.append("</thead>");
        //body
        b.append("<tbody>");
        for (int i = 1; i < list.size(); i++){
            b.append("<tr>");
            for (String col : (String[]) list.get(i)) b.append("<td>").append(col).append("</td>");
            b.append("</tr>");
        }
        b.append("</body>");
        b.append("</table>");

        return b.toString();
    }
    
    @Override
    public void acceptClaim(String id){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE CLAIMS SET STATUS='Approved' WHERE ID=" + id);
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    @Override
    public void approveMember(String email){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE USERS SET STATUS='Approved' WHERE EMAIL='" + email + "'");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public void suspendMember(String email){
        try {
            statement = cons.createStatement();
            statement.executeUpdate("UPDATE USERS SET STATUS='Suspended' WHERE EMAIL='" + email + "'");
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    @Override
    public boolean checkUsername(String username){
        try {
            statement = cons.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_READ_ONLY);
            resultSet = statement.executeQuery("SELECT * FROM ADMIN WHERE ADMINUSER='" + username + "'");
            
            while (resultSet.next()) return true;
            
        } catch (SQLException ex) {
            Logger.getLogger(AdminDAOImpl.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        return false;
    }
}
