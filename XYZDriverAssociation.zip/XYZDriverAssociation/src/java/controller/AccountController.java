/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import model.Claim;
import model.User;

/**
 *
 * @author tuan
 */
public class AccountController extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");
        HttpSession session = request.getSession();
        if (action == null) {
            User user = checkCookie(request);
            if (user == null) {

                //khong check remember me, nghia la khong luu cookie trong browser
                // session.removeAttribute("username");
                session.removeAttribute("email");

                request.getRequestDispatcher("userdashboard.jsp").forward(request, response);

            } else {//check remeber me, nghia la co luu cookie trong browser
                if (new UserDAOImpl().checkLogin(user.getEmail(), user.getPassword())) {
                    //session.setAttribute("username", new UserDAOImpl().getUserNameFromEmail(user.getEmail()));
                    session.setAttribute("email", user.getEmail());
                    request.getRequestDispatcher("userdashboard.jsp").forward(request, response);
                }
            }
        } else if (action.equals("logout")) {
            request.getRequestDispatcher("login.jsp").forward(request, response);
            // <editor-fold defaultstate="collapsed" desc="Log Out Action">
            //remove session
            //session.removeAttribute("username");
            session.removeAttribute("email");
            //remove cookie
            Cookie[] cookies = request.getCookies();
            for (Cookie c : cookies) {
                if (c.getName().equalsIgnoreCase("email")) {
                    c.setMaxAge(0);
                    response.addCookie(c);
                }
                if (c.getName().equalsIgnoreCase("password")) {
                    c.setMaxAge(0);
                    response.addCookie(c);
                }
            }
            request.getRequestDispatcher("login.jsp").forward(request, response);
            //</editor-fold>
        } else if (action.equals("feedback")) {
            // <editor-fold defaultstate="collapsed" desc="Feedback Action">
            if (session.getAttribute("username") != null && session.getAttribute("email") != null) {
                request.getRequestDispatcher("feedback.jsp").forward(request, response);
            } else {
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
            //</editor-fold>
        } else if (action.equals("checkout")) {
            // <editor-fold defaultstate="collapsed" desc="Checkout Action">
            if (session.getAttribute("cart") == null) {
                request.getRequestDispatcher("index.jsp").forward(request, response);
            } else {
                response.sendRedirect("checkout.jsp");
            }
            //</editor-fold>
        } else {
            request.getRequestDispatcher("login.jsp").forward(request, response);
        }
    }

    private User checkCookie(HttpServletRequest request) {
        // <editor-fold defaultstate="collapsed" desc="check cookie">
        Cookie[] cookies = request.getCookies();
        User user = null;
        String email = "", password = "";

        if (cookies != null) {

            for (Cookie c : cookies) {
                if (c.getName().equalsIgnoreCase("email")) {
                    email = c.getValue();
                }
                if (c.getName().equalsIgnoreCase("password")) {
                    password = c.getValue();
                }

            }
            if (!email.isEmpty() && !password.isEmpty()) {
                user = new User("", email, "", 0, "", password, 0, 0, 0, 0,"");
            }

        }
        return user;
        // </editor-fold>
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String action = request.getParameter("action");

        if (action.equals("login")) {
            // <editor-fold defaultstate="collapsed" desc="Login Action">
            //final String secretKey = "secretkeysecretkey";
            String email = request.getParameter("email");
            String password = request.getParameter("password");
            boolean rememberMe = request.getParameter("remember") != null;
            //String encryptedPassword = AES.encrypt(password, secretKey);
            //String username = new UserDAOImpl().getUserNameFromEmail(email);

            String password_err = "err", email_err = "err";

            if (email.equals("") || password.equals("")) {

                request.setAttribute("login_err", "Please input email and password to login!");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_login_err", "Invalid email format!");

            } else {
                if (!new UserDAOImpl().checkLogin(email, password)) {
                    request.setAttribute("login_err", "Login failed!");
                } else {

                    email_err = "";
                    password_err = "";
                }
            }

            String url = "";

            if (!password_err.equals("") || !email_err.equals("")) {
                url = "/login.jsp";

            } else {
                url = request.getParameter("checkout") != null ? "/checkout.jsp" : "/userdashboard.jsp";
                HttpSession s = request.getSession();
                //s.setAttribute("username", username);
                s.setAttribute("email", email);

                if (rememberMe) {
                    Cookie c = new Cookie("email", email);
                    c.setMaxAge(3600);// expire one hour
                    response.addCookie(c);

                    Cookie c1 = new Cookie("password", password);
                    c.setMaxAge(3600);
                    response.addCookie(c1);
                }
            }

            if (url.equals("/checkout.jsp")) {
                response.sendRedirect("AccountController?action=checkout");
            } else {
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            }
            // </editor-fold>
        } else if (action.equals("signup")) {
            // <editor-fold defaultstate="collapsed" desc="Sign Up Action">
            String email = request.getParameter("email").trim();
            String fullname = request.getParameter("fullname").trim();
            String status = "Applied";
            String dob = request.getParameter("dob").trim();            
            String address = request.getParameter("address").trim();
            int balance = 0;
            String password = request.getParameter("password").trim();
            String account = request.getParameter("account").trim();
            String code = request.getParameter("code").trim();
            String month = request.getParameter("month").trim();
            String year = request.getParameter("year").trim();
            String password_err = "err", account_err = "err", code_err = "err", month_err = "err", year_err = "err";
            String email_err = "err", fullname_err = "err", address_err = "err";

            if (fullname.equals("")) {

                request.setAttribute("fullname_err", "Please input your user name");

            } else if (!fullname.matches("^[a-zA-Z0-9]+(([\\_\\-][a-zA-Z 0-9])?[a-zA-Z0-9]*)*$") || fullname.length() < 6 || fullname.length() > 20) {
                request.setAttribute("fullname_err", "the length is 6 to 20, no space, no special character");
            } else {
                request.setAttribute("fullname", fullname);
                fullname_err = "";
            }

            if (email.equals("")) {

                request.setAttribute("email_err", "Please input your email!");

            } else if (new UserDAOImpl().checkAccountExist(email)) {
                request.setAttribute("email_err", "email exists");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_err", "Invalid email format!");

            } else {
                request.setAttribute("email", email);
                email_err = "";
            }

            if (address.equals("")) {

                request.setAttribute("address_err", "Please input your address!");

            } else if (!address.matches("^([a-zA-Z0-9]+\\s)*[a-zA-Z0-9]+$") || address.length() < 6 || address.length() > 300) {
                request.setAttribute("address_err", "10 to 300 characters required, no more than 1 space, no special characters");

            } else {
                request.setAttribute("address", address);
                address_err = "";
            }
            if (password.equals("")) {

                request.setAttribute("password_err", "Please generate your password!");

            } else {
                request.setAttribute("password", password);
                password_err = "";
            }
            if (account.equals("")) {

                request.setAttribute("account_err", "Please input your account number!");

            } else if (account.length() == 16) {
                request.setAttribute("account_err", "invalid numbers account");

            } else {
                request.setAttribute("account", account);
                account_err = "";
            }
            if (code.equals("")) {

                request.setAttribute("code_err", "Please input your security code!");

            } else {
                request.setAttribute("code", code);
                code_err = "";
            }

            if (month.equals("")) {

                request.setAttribute("month_err", "Please select month!");

            } else {
                request.setAttribute("month", month);
                month_err = "";
            }
            if (year.equals("")) {

                request.setAttribute("year_err", "Please select year!");

            } else {
                request.setAttribute("year", year);
                year_err = "";
            }

            String url = "";

            if (!email_err.equals("") || !fullname_err.equals("") || !address_err.equals("") || !password_err.equals("") || !account_err.equals("") || !code_err.equals("") || !month_err.equals("") || !year_err.equals("")) {
                url = "/register.jsp";
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            } else {
                url = "/homepage.jsp";
                //String encryptedPassword = AES.encrypt(password, secretKey);
                User u = new User(fullname, email, status,Double.valueOf(balance), address, password, Integer.parseInt(account), Integer.parseInt(code), Integer.parseInt(month), Integer.parseInt(year),dob);
                new UserDAOImpl().insertAccount(u);

                HttpSession s = request.getSession();
                s.setAttribute("username", email);
                s.setAttribute("email", email);
                s.setAttribute("success", "SIGN UP SUCCESSFULLY!");
                response.sendRedirect("homepage.jsp");
            }

            // </editor-fold>
        } else if (action.equals("update")) {
            // <editor-fold defaultstate="collapsed" desc="Update Action">
            String email = request.getParameter("email").trim();
            String fullname = request.getParameter("fullname").trim();
            String status = "Applied";
            String dob = request.getParameter("dob").trim();
            String address = request.getParameter("address").trim();
            int balance = 0;
            String password = request.getParameter("password").trim();
            String account = request.getParameter("account").trim();
            String code = request.getParameter("code").trim();
            String month = request.getParameter("month").trim();
            String year = request.getParameter("year").trim();
            HttpSession s = request.getSession();

            String password_err = "err", account_err = "err", code_err = "err", month_err = "err", year_err = "err";
            String email_err = "err", fullname_err = "err", address_err = "err";

            if (fullname.equals("")) {

                request.setAttribute("fullname_err", "Please input your user name");

            } else if (!fullname.matches("^[a-zA-Z0-9]+(([\\_\\-][a-zA-Z 0-9])?[a-zA-Z0-9]*)*$") || fullname.length() < 6 || fullname.length() > 20) {
                request.setAttribute("fullname_err", "the length is 6 to 20, no space, no special character");
            } else {
                request.setAttribute("fullname", fullname);
                fullname_err = "";
            }

            if (email.equals("")) {

                request.setAttribute("email_err", "Please input your email!");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_err", "Invalid email format!");

            } else {
                request.setAttribute("email", email);
                email_err = "";
            }

            if (address.equals("")) {

                request.setAttribute("address_err", "Please input your address!");

            } else if (!address.matches("^([a-zA-Z0-9]+\\s)*[a-zA-Z0-9]+$") || address.length() < 6 || address.length() > 300) {
                request.setAttribute("address_err", "10 to 300 characters required, no more than 1 space, no special characters");

            } else {
                request.setAttribute("address", address);
                address_err = "";
            }
            if (password.equals("")) {

                request.setAttribute("password_err", "Please generate your password!");

            } else {
                request.setAttribute("password", password);
                password_err = "";
            }
            if (account.equals("")) {

                request.setAttribute("account_err", "Please input your account number!");

            } else if (account.length() == 16) {
                request.setAttribute("account_err", "invalid numbers account");

            } else {
                request.setAttribute("account", account);
                account_err = "";
            }
            if (code.equals("")) {

                request.setAttribute("code_err", "Please input your security code!");

            } else {
                request.setAttribute("code", code);
                code_err = "";
            }

            if (month.equals("")) {

                request.setAttribute("month_err", "Please select month!");

            } else {
                request.setAttribute("month", month);
                month_err = "";
            }
            if (year.equals("")) {

                request.setAttribute("year_err", "Please select year!");

            } else {
                request.setAttribute("year", year);
                year_err = "";
            }

            String url = "";

            if (!email_err.equals("") || !fullname_err.equals("") || !address_err.equals("") || !password_err.equals("") || !account_err.equals("") || !code_err.equals("") || !month_err.equals("") || !year_err.equals("")) {
                url = "/userprofile.jsp";
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            } else {
                url = "/homepage.jsp";
                //String encryptedPassword = AES.encrypt(password, secretKey);
                User u = new User(fullname, email, status, balance, address, password, Integer.parseInt(account), Integer.parseInt(code),Integer.parseInt(month), Integer.parseInt(year),dob);
                new UserDAOImpl().updateAccount(u);

                s.setAttribute("email", email);
                s.setAttribute("success", "Update SUCCESSFULLY!");
                response.sendRedirect("homepage.jsp");
            }

            //editor-fold
        } else if (action.equals("claim")) {
            HttpSession s = request.getSession();
            String rational = request.getParameter("rational").trim();
            String date = request.getParameter("date").trim();
            String amount = request.getParameter("amount").trim();
            String email = request.getParameter("email").trim();
            String amount_err = "err", rational_err = "err", date_err = "err", email_err = "err";
            String status = "Applied";

            if (email.equals("")) {

                request.setAttribute("email_err", "Please input your email!");

            } else if (!email.matches("(?:[a-z0-9!#$%&'*+/=?^_`{|}~-]+(?:\\.[a-z0-9!#$%&'*+/=?^_`{|}~-]+)*|\"(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21\\x23-\\x5b\\x5d-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])*\")@(?:(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\\.)+[a-z0-9](?:[a-z0-9-]*[a-z0-9])?|\\[(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?|[a-z0-9-]*[a-z0-9]:(?:[\\x01-\\x08\\x0b\\x0c\\x0e-\\x1f\\x21-\\x5a\\x53-\\x7f]|\\\\[\\x01-\\x09\\x0b\\x0c\\x0e-\\x7f])+)\\])")) {
                request.setAttribute("email_err", "Invalid email format!");

            } else {
                request.setAttribute("email", email);
                email_err = "";
            }

            if (rational.equals("")) {

                request.setAttribute("rational_err", "Please give us more deatails about your claims");

            } else {
                request.setAttribute("rational", rational);
                rational_err = "";
            }

            if (date.equals("")) {

                request.setAttribute("date_err", "Please give us exactly time");

            } else {
                request.setAttribute("date", date);
                date_err = "";
            }
            
            if (amount.equals("")) {

                request.setAttribute("amount_err", "Please give bill");

            } else {
                request.setAttribute("amount", amount);
                amount_err = "";
            }

           
            String url = "";

            if (!rational_err.equals("") || !date_err.equals("") || !email_err.equals("") || !amount_err.equals("")) {
                url = "/claims.jsp";
                RequestDispatcher rd = getServletContext().getRequestDispatcher(url);
                rd.forward(request, response);
            } else {
                url = "/userdashboard.jsp";
                Claim u = new Claim(email, rational, date, Integer.parseInt(amount), status);
                new UserDAOImpl().insertClaim(u);

                s.setAttribute("email", email);
                s.setAttribute("success", "Update SUCCESSFULLY!");
                response.sendRedirect("userdashboard.jsp");
            }

        }
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
