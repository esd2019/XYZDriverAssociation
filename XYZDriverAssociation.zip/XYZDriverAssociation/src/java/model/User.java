/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;



public class User {
    private int userID;
    private String fullname;
    private String password;
    private boolean status;
    private String address;
    private String email;
    private String dob;
    private int balance = 0;
    private int account;
    private int code;
    private String month;
    private String year;

    public User(String fullname, String email, String dob,boolean status, int balance, String address,String password, int account, int code, String month, String year) {
        this.userID = userID;
        this.fullname = fullname;      
        this.status = status;        
        this.address = address;
        this.email = email;
        this.dob = dob;
        this.balance = balance;
        this.password = password;
        this.account = account;
        this.code  = code;
        this.month = month;
        this.year = year;
        
    }

    public User() {
    }

    public User( String password, int account, int code, String month, String year, boolean status){
        
        this.password = password;
        this.account = account;
        this.code  = code;
        this.month = month;
        this.year = year;
        this.status = status;
        
        
    }

    public int getAccount() {
        return account;
    }

    public void setAccount(int account) {
        this.account = account;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMonth() {
        return month;
    }

    public void setMonth(String month) {
        this.month = month;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

    
    

 
    
    
}
