/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import dao.UserDAOImpl;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import model.Payment;

/**
 *
 * @author jennistly
 */
public class memberPayments extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        String description = request.getParameter("description").trim();
            String code = request.getParameter("code").trim();
            String mem_id = request.getParameter("mem_id").trim();
            String amount = request.getParameter("amount").trim();
            String date = request.getParameter("date").trim();
            String type = request.getParameter("type").trim();
            String outstanding_id = request.getParameter("outstanding_id").trim();
            request.setAttribute("description", description);
            request.setAttribute("outstanding_id", outstanding_id);
            request.setAttribute("code", code);
            request.setAttribute("mem_id", mem_id);
            request.setAttribute("date", date);
            request.setAttribute("type", type);
            request.setAttribute("amount", amount);
            String url = "";
            url = "user/userdashboard.jsp";
            Payment u = new Payment(Integer.parseInt(mem_id),Integer.parseInt(outstanding_id), type,  Double.parseDouble(amount), code,description,date);
            new UserDAOImpl().insertPayment(u);
            response.sendRedirect("user/userdashboard.jsp");
            
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
